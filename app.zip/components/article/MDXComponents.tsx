"use client";

import React from "react";
import Image from "next/image";
import AfiliadosCard from "@/components/home/AfiliadosCard";
import ProductRow from "@/components/article/ProductRow";
import WrapImageText from "@/components/article/WrapImageText";
import ArticleButton from "@/components/article/ArticleButton";
import AffiliatePriceLinks from "@/components/article/AffiliatePriceLinks";

type Afiliado = {
  nome: string;
  url: string;
  cor?: string;
  texto?: string;
  logo?: string;
};

type AfiliadosCardProps = {
  imagem?: string;
  imagens?: string[];
  titulo: string;
  descricao: string;
  loja: string;
  preco: string;
  afiliados?: Afiliado[];
  // Props para MDX - apenas ID
  afiliadoId?: string;
};

export function Affiliate({
  url,
  children,
}: {
  url: string;
  children: React.ReactNode;
}) {
  return (
    <a
      href={url}
      target="_blank"
      rel="nofollow noopener noreferrer sponsored"
      className="inline-block px-3 py-1 border rounded"
    >
      {children}
    </a>
  );
}

export function AffiliateBox({
  url,
  title,
  description,
  price,
  buttonText = "Ver Oferta",
}: {
  url: string;
  title: string;
  description?: string;
  price?: string;
  buttonText?: string;
}) {
  return (
    <div className="my-6 p-6 bg-linear-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl shadow-lg">
      <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
      {description && <p className="text-gray-700 mb-4">{description}</p>}
      {price && (
        <p className="text-2xl font-bold text-blue-600 mb-4">{price}</p>
      )}
      <a
        href={url}
        target="_blank"
        rel="nofollow noopener noreferrer sponsored"
        className="inline-block px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors"
      >
        {buttonText} →
      </a>
    </div>
  );
}

export function ProductCard({
  url,
  title,
  description,
  price,
  image,
  buttonText = "Ver Produto",
}: {
  url: string;
  title: string;
  description?: string;
  price?: string;
  image?: string;
  buttonText?: string;
}) {
  return (
    <div className="my-6 overflow-hidden bg-white border border-gray-200 rounded-xl shadow-md hover:shadow-xl transition-shadow">
      {image && (
        <div className="relative w-full h-48">
          <Image
            src={image}
            alt={title}
            fill
            unoptimized
            className="object-cover"
          />
        </div>
      )}
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        {description && <p className="text-gray-600 mb-4">{description}</p>}
        {price && (
          <p className="text-2xl font-bold text-green-600 mb-4">{price}</p>
        )}
        <a
          href={url}
          target="_blank"
          rel="nofollow noopener noreferrer sponsored"
          className="inline-block w-full text-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
        >
          {buttonText} →
        </a>
      </div>
    </div>
  );
}

export function SpecsTable({ specs }: { specs: Record<string, string> }) {
  return (
    <div className="my-6 overflow-hidden border border-gray-200 rounded-xl">
      <table className="w-full">
        <tbody>
          {Object.entries(specs).map(([key, value], index) => (
            <tr
              key={key}
              className={index % 2 === 0 ? "bg-gray-50" : "bg-white"}
            >
              <td className="px-6 py-3 font-semibold text-gray-900 border-r border-gray-200 w-1/3">
                {key}
              </td>
              <td className="px-6 py-3 text-gray-700">{value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function AfiliadosCardBlock(props: AfiliadosCardProps) {
  // Se já veio com afiliados array (compatibilidade anterior)
  if (props.afiliados && props.afiliados.length > 0) {
    return (
      <div className="not-prose my-3 mx-auto w-[150px] md:w-[200px] lg:w-[200px]">
        <AfiliadosCard {...props} afiliados={props.afiliados} />
      </div>
    );
  }

  // Se veio com todos os campos necessários para renderizar
  if (props.titulo && props.loja && props.preco) {
    return (
      <div className="not-prose my-3 mx-auto w-[150px] md:w-[200px] lg:w-[200px]">
        <AfiliadosCard {...props} afiliados={props.afiliados || []} />
      </div>
    );
  }

  // Fallback vazio se não tem dados
  return null;
}

export const components = {
  a: (props: React.AnchorHTMLAttributes<HTMLAnchorElement>) => (
    <a {...props} className="text-accent underline" />
  ),
  p: (props: React.HTMLAttributes<HTMLParagraphElement>) => {
    // Evita <p> dentro de <p> filtrando children que já são elementos block
    const { children, ...rest } = props;
    const mergedClassName =
      `${rest.className || ""} whitespace-pre-line`.trim();

    // Verifica se há elementos block dentro do parágrafo
    const hasBlockElement = React.Children.toArray(children).some((child) => {
      if (!React.isValidElement(child)) return false;
      // Componentes React (não strings) que produzem elementos block: renderiza como div
      if (typeof child.type !== "string") return true;
      const blockElements = [
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "ul",
        "ol",
        "blockquote",
        "div",
        "article",
        "figure",
        "p",
      ];
      return blockElements.includes(child.type);
    });

    if (hasBlockElement) {
      return (
        <div {...rest} className={mergedClassName}>
          {children}
        </div>
      );
    }

    const preserveLineBreaks = (node: React.ReactNode): React.ReactNode => {
      if (typeof node !== "string") return node;

      const parts = node.split("\n");
      return parts.flatMap((part, index) =>
        index < parts.length - 1 ? [part, <br key={`br-${index}`} />] : [part],
      );
    };

    const normalizedChildren = React.Children.map(children, (child) =>
      preserveLineBreaks(child),
    );

    return (
      <p {...rest} className={mergedClassName}>
        {normalizedChildren}
      </p>
    );
  },
  Affiliate,
  AffiliateBox,
  ProductCard,
  SpecsTable,
  AfiliadosCard: AfiliadosCardBlock,
  AfiliadosCardBlock,
  ProductRow,
  WrapImageText,
  ArticleButton,
  AffiliatePriceLinks,
  strong: (props: React.HTMLAttributes<HTMLElement>) => (
    <strong
      {...props}
      className={`font-[560] text-slate-900 ${props.className || ""}`.trim()}
    />
  ),
  b: (props: React.HTMLAttributes<HTMLElement>) => (
    <b
      {...props}
      className={`font-[560] text-slate-900 ${props.className || ""}`.trim()}
    />
  ),
  ul: (props: React.HTMLAttributes<HTMLUListElement>) => (
    <ul
      {...props}
      className={`list-disc pl-6 mt-0 mb-6 space-y-1 ${props.className || ""}`.trim()}
    />
  ),
  ol: (props: React.HTMLAttributes<HTMLOListElement>) => (
    <ol
      {...props}
      className={`list-decimal pl-6 mt-0 mb-6 space-y-1 ${props.className || ""}`.trim()}
    />
  ),
  li: (props: React.LiHTMLAttributes<HTMLLIElement>) => (
    <li {...props} className={`leading-7 ${props.className || ""}`.trim()} />
  ),
  hr: (props: React.HTMLAttributes<HTMLHRElement>) => (
    <hr {...props} className={`my-5 ${props.className || ""}`.trim()} />
  ),
  table: (props: React.TableHTMLAttributes<HTMLTableElement>) => (
    <div className="my-6 w-full overflow-x-auto">
      <table
        {...props}
        className={`min-w-[640px] w-full border-collapse ${props.className || ""}`.trim()}
      />
    </div>
  ),
  th: (props: React.ThHTMLAttributes<HTMLTableCellElement>) => (
    <th
      {...props}
      className={`border border-slate-300 px-3 py-2 text-left font-semibold ${props.className || ""}`.trim()}
    />
  ),
  td: (props: React.TdHTMLAttributes<HTMLTableCellElement>) => (
    <td
      {...props}
      className={`border border-slate-200 px-3 py-2 ${props.className || ""}`.trim()}
    />
  ),
};
