// components/ProductRow.tsx
import React from "react";
import Image from "next/image";

type ProductRowProps = {
  image: string;
  title: string;
  url?: string;
  children?: React.ReactNode;
};

export default function ProductRow({
  image,
  title,
  url,
  children,
}: ProductRowProps) {
  const safeTitle =
    typeof title === "string" && title.trim().length > 0 ? title.trim() : "";

  const imageElement = (
    <div className="relative w-[220px] h-[220px] md:w-[336px] md:h-[336px] rounded-xl overflow-hidden flex-shrink-0 mx-auto md:mx-0">
      <Image
        src={image}
        alt={safeTitle}
        fill
        sizes="(min-width: 768px) 336px, 220px"
        unoptimized
        className="object-contain"
      />
    </div>
  );

  return (
    <div className="flex flex-col md:flex-row gap-6 items-start md:items-center my-0">
      {url ? (
        <a
          href={url}
          target="_blank"
          rel="nofollow noopener noreferrer sponsored"
          className="hover:opacity-80 transition-opacity"
        >
          {imageElement}
        </a>
      ) : (
        imageElement
      )}

      <div
        className="w-full space-y-3 text-left text-slate-900 max-w-none
        [&_h1]:text-3xl [&_h1]:font-extrabold [&_h1]:leading-tight [&_h1]:mt-0 [&_h1]:mb-3
        [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:leading-tight [&_h2]:mt-0 [&_h2]:mb-3
        [&_h3]:text-xl [&_h3]:font-bold [&_h3]:leading-tight [&_h3]:mt-0 [&_h3]:mb-2
        [&_p]:text-base [&_p]:leading-7 [&_p]:text-slate-800
        [&_ul]:list-disc [&_ul]:pl-5 [&_li]:mb-1"
      >
        {safeTitle && (
          <h3 className="text-xl font-bold mb-2 !mb-3 !mt-0">{safeTitle}</h3>
        )}

        {children}
      </div>
    </div>
  );
}
